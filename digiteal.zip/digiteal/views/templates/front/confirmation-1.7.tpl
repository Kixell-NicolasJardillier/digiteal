{*
* NOTICE OF LICENSE
*
* Digiteal for PrestaShop is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* https://opensource.org/licenses/afl-3.0.php
*
* @author    SARL KIXELL (https://kixell.fr)
* @copyright Copyright © 2021 - SARL Kixell
* @license   https://opensource.org/licenses/afl-3.0.php Academic Free License (AFL 3.0)
* @package   digiteal
* @version   1.0.5
*}
{extends file='page.tpl'}
{block name='page_content'}
    <section class="digiteal-wait">
        <div class="digiteal-wait__card" id="digiteal_content">
            <svg class="digiteal-wait__logo" enable-background="new 0 0 130.3 150" viewBox="0 0 130.3 150" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><g fill="#0db5c0"><path d="m64.7 150 41.2-23.4h-82.5z"/><path d="m130.3 67.5h-55.3l39.4-39.4 15.9 9.4z"/><path d="m130.3 94.7h-83.4l24.3-23.5h59.1z"/><path d="m130.3 112.5-17.8 10.3h-92.8l24.4-24.4h86.2z"/><path d="m15.9 121.9 95.7-94.7-46.9-27.2-64.7 37.5v75z"/></g></svg>

            <h1 class="digiteal-wait__title">{l s='Redirecting ...' mod='digiteal'}</h1>

            <p class="digiteal-wait__text">{l s='Please wait, you will be redirected to the order confirmation page.' mod='digiteal'}</p>

            <div class="digiteal-wait__bar" role="progressbar" aria-live="off"></div>

            <p class="digiteal-wait__count">
                {l s='In' mod='digiteal'}&nbsp;<span class="digiteal-wait__seconds" id="digiteal_elapsed_time" data-url="{$digiteal_elapsed_time_url}" data-default="{$digiteal_default_url_redirect}">{$digiteal_elapsed_time}</span>&nbsp;{l s='seconds' mod='digiteal'}
            </p>

            <noscript>
                <p class="digiteal-wait__fallback">
                    <a class="btn btn-primary" href="{$digiteal_fallback_url|escape:'html':'UTF-8'}">{l s='Continue' mod='digiteal'}</a>
                </p>
            </noscript>
        </div>
    </section>
{/block}
